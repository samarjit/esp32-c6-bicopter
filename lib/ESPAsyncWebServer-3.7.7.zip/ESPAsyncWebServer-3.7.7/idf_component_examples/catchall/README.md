### Basic example to show how to catch all requests and send a 404 Not Found response
